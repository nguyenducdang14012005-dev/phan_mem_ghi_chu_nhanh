import React, { useState } from "react";
import ReactQuill from "react-quill-new";
import "react-quill-new/dist/quill.snow.css"; // Stylesheet bắt buộc của Quill
import { NOTE_COLORS } from "../constants/noteColors.js";

export default function NoteComposer({
  view,
  composerOpen,
  setComposerOpen,
  newTitle,
  setNewTitle,
  newContent,
  setNewContent,
  newDueTime,
  setNewDueTime,
  newColor,
  setNewColor,
  datePickerOpen,
  setDatePickerOpen,
  createNote,
}) {
  const [colorPickerOpen, setColorPickerOpen] = useState(false);
  if (view !== "notes") return null;

  const color = newColor || "#ffffff";

  // Hàm xử lý khi người dùng nhấn nút "Hủy"
  const handleCancel = () => {
    setNewTitle("");
    setNewContent("");
    setNewDueTime("");
    if (setNewColor) setNewColor("#ffffff");
    setComposerOpen(false);
    if (setDatePickerOpen) setDatePickerOpen(false);
  };

  // ⚡ Toolbar đặt ở dưới khung soạn thảo (xem #composer-toolbar-bottom bên dưới),
  // để với ghi chú dài, người dùng không phải kéo lên đầu trang mới bấm được nút định dạng.
  const modules = {
    toolbar: {
      container: "#composer-toolbar-bottom",
    },
  };

  const formats = [
    "header",
    "bold",
    "italic",
    "underline",
    "strike",
    "color",
    "background",
    "list",
    "bullet",
    "align",
  ];

  return (
    <div className="composer-wrapper">
      {!composerOpen ? (
        /* Nhấn vào bất kỳ vị trí nào của composer-collapsed đều mở trình soạn thảo */
        <div
          className="composer-collapsed"
          onClick={() => setComposerOpen(true)}
        >
          <span>
            {newContent ? newContent.replace(/<[^>]*>/g, "") : "Ghi chú..."}
          </span>
        </div>
      ) : (
        <div className="composer-expanded" style={{ backgroundColor: color }}>
          {/* Ô nhập tiêu đề giữ nguyên là input text thông thường */}
          <input
            className="composer-title"
            placeholder="Tiêu đề"
            value={newTitle}
            onChange={(e) => setNewTitle(e.target.value)}
            autoFocus
          />

          {/* Thay thế input nội dung cũ bằng Rich Text Editor */}
          <div
            className="composer-editor-container"
            style={{ margin: "10px 0" }}
          >
            <ReactQuill
              theme="snow"
              value={newContent}
              onChange={setNewContent}
              placeholder="Ghi chú..."
              modules={modules}
              formats={formats}
            />

            {/* ⚡ Toolbar đặt SAU khung soạn thảo (không phải mặc định ở trên),
                để đoạn văn dài vẫn luôn thấy nút định dạng mà không cần kéo lên đầu */}
            <div id="composer-toolbar-bottom" className="ql-toolbar ql-snow composer-toolbar-bottom">
              <span className="ql-formats">
                <select className="ql-header" defaultValue="">
                  <option value="1" />
                  <option value="2" />
                  <option value="" />
                </select>
              </span>
              <span className="ql-formats">
                <button className="ql-bold" />
                <button className="ql-italic" />
                <button className="ql-underline" />
                <button className="ql-strike" />
              </span>
              <span className="ql-formats">
                <select className="ql-color" />
                <select className="ql-background" />
              </span>
              <span className="ql-formats">
                <button className="ql-list" value="ordered" />
                <button className="ql-list" value="bullet" />
              </span>
              <span className="ql-formats">
                <select className="ql-align" />
              </span>
              <span className="ql-formats">
                <button className="ql-clean" />
              </span>
            </div>
          </div>

          <button
            className="deadline-btn"
            onClick={() => setDatePickerOpen(!datePickerOpen)}
          >
            {newDueTime
              ? new Date(newDueTime).toLocaleString("vi-VN")
              : "Chọn ngày và giờ"}
          </button>

          {datePickerOpen && (
            <div className="date-picker-popup">
              <div className="date-picker-header">
                <span>← Chọn ngày và giờ</span>
              </div>
              <div className="date-picker-body">
                <input
                  type="date"
                  className="date-input"
                  value={newDueTime.split("T")[0] || ""}
                  onChange={(e) =>
                    setNewDueTime(
                      e.target.value +
                        "T" +
                        (newDueTime.split("T")[1] || "00:00"),
                    )
                  }
                />
                <input
                  type="time"
                  className="time-input"
                  value={newDueTime.split("T")[1] || ""}
                  onChange={(e) =>
                    setNewDueTime(
                      (newDueTime.split("T")[0] || "") + "T" + e.target.value,
                    )
                  }
                />
              </div>
              <div className="date-picker-footer">
                <button
                  className="btn-share"
                  onClick={() => setDatePickerOpen(false)}
                >
                  Lưu
                </button>
              </div>
            </div>
          )}

          <div
            className="composer-actions"
            style={{
              marginTop: "14px",
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
            }}
          >
            {/* Tách riêng hai nút chức năng Lưu và Hủy */}
            <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
              <div style={{ position: "relative" }}>
                <button
                  type="button"
                  className="card-btn"
                  title="Chọn màu"
                  onClick={() => setColorPickerOpen((v) => !v)}
                >
                  <img
                    src="/images/palette.png"
                    alt="Ghim"
                    style={{
                      width: "18px",
                      height: "18px",
                      objectFit: "contain",
                    }}
                  />
                </button>
                {colorPickerOpen && (
                  <div className="color-picker-popup">
                    {NOTE_COLORS.map((c) => (
                      <button
                        key={c.value}
                        type="button"
                        title={c.name}
                        className={`color-dot ${color === c.value ? "selected" : ""}`}
                        style={{ backgroundColor: c.value }}
                        onClick={() => {
                          if (setNewColor) setNewColor(c.value);
                          setColorPickerOpen(false);
                        }}
                      />
                    ))}
                  </div>
                )}
              </div>
              <button
                className="close-btn"
                style={{ background: "#f1f3f4", color: "#5f6368" }}
                onClick={handleCancel}
              >
                Hủy
              </button>
              <button className="btn-share" onClick={createNote}>
                Lưu
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
